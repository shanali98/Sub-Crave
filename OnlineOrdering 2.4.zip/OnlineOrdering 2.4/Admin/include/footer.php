<div class="footer">
	<div class="container"> 
		<b class="copyright">&copy; 2022 Online Food Ordering System - Team ENIAC </b> All rights reserved.
	</div>
</div>