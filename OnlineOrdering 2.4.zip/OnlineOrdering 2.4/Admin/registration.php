<?php
	session_start();
	error_reporting(0);
	if (isset($_SESSION['alogin'])) 
	{
		header("location:dashboard.php");
	}
	include("include/config.php");
	
	if(isset($_POST['submit']))
	{
		$fname=$_POST['fname'];
		$Jobtype=$_POST['jtype'];
		$userName=$_POST['uname'];
		$password=md5($_POST['password']);
		$cPassword=md5($_POST['confirmpassword']);

		$sql_u = "SELECT * FROM staff WHERE userName='$userName'";

		$res_u = mysqli_query($conn, $sql_u);

		//Check username already used or not
		if (mysqli_num_rows($res_u) > 0 ) 
		{
			$_SESSION['errmsg']="This User Name is already used. Please try another";
			
				
		}
		
		else{
			
			if( $_POST["password"] === $_POST["confirmpassword"]){
				
				$query=mysqli_query($conn,"insert into staff(fullName,jobType,userName,password,confirmPassword) values('$fname','$Jobtype','$userName','$password','$cPassword')");
				if($query)
				{

					echo "<script>alert('You are successfully register');</script>";
					header("location:index.php");
				}
				else{
					echo "<script>alert('Not register something went worng');</script>";
				}
			} 
			else{
				$_SESSION['Warmsg']="Passwords do not match";
				
			}
		}
		
	}
	mysqli_close($conn);
?>



<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<title>Admin | Registartion</title>

		<link type="text/css" href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
		<link type="text/css" href="css/theme.css" rel="stylesheet">
		<link type="text/css" href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>
		
		
	</head>
	<body>
		<div class="navbar navbar-fixed-top">
			<div class="navbar-inner">
				<div class="container">
					<a class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-inverse-collapse">
						<i class="icon-reorder shaded"></i>
					</a>

					<div class="nav-collapse collapse navbar-inverse-collapse">					
						<ul class="nav pull-right">
							<li>
								<br>
								<a href="../index.php">Back to Portal</a>
							</li>													
						</ul>
						
						<a class="brand" href="index.php" > <img src="logo.jpeg" width="70px"/> &nbsp;&nbsp; Staff Registration</a>		
					</div><!-- /.nav-collapse -->
				</div>
			</div><!-- /navbar-inner -->
		</div><!-- /navbar -->

		<div class="wrapper">
			<div class="container" >				
				<div class="row">
					<div class="module module-login span7 offset2">
						<form class="form-vertical" method="post" role="form">
							<div class="module-head">
								<h3>Registration</h3>
							</div>
							
							<div class="module-body" >
								<table>
									<tr>
										<div class="controls row-fluid">
											<td width="20%">Full Name <br><br></td>
											<td><input class="span5" type="text" id="fname" name="fname" placeholder="Full Name" required><br><br></td>
										</div>
									</tr>
									<tr>

										<div class="controls row-fluid">
											<td width="20%"> Job Type <br><br></td>
											<td> <input class="span5" type="text" id="jtype" name="jtype" placeholder="Job Type" required><br><br></td>
										</div>
									</tr>
									<tr>
										<td></td>
										<td><span style="color:red;" ><?php echo htmlentities($_SESSION['errmsg']); ?><?php echo htmlentities($_SESSION['errmsg']="");?></span></td>
									</tr>
									<tr>
										<div class="controls row-fluid">
											<td>User Name <br><br></td>
											<td><input class="span5" type="text" id="uname" name="uname" placeholder="User Name" required><br><br> </td>
										</div>
									</tr>
									<tr>
										<div class="controls row-fluid">
											<td>Password <br><br></td> 
											<td><input class="span5" type="password" id="password" name="password" placeholder="Password" required><br><br></td>
										</div>
									</tr>
									<tr>
										<td></td>
										<td><span style="color:#CC3300" ><?php echo htmlentities($_SESSION['Warmsg']); ?><?php echo htmlentities($_SESSION['Warmsg']="");?></span></td>
									</tr>
									<tr>
										<div class="controls row-fluid">
											<td>Confirm Password <br><br></td>
											<td><input class="span5" type="password" id="confirmpassword" name="confirmpassword" placeholder="Confirm Password" required><br><br></td>
										</div>

									</tr>
								</table>
							</div>
							<div class="module-foot">
								<div class="control-group">
									<div class="controls clearfix" style="text-align: right">
										<button type="submit" class="btn btn-primary pull-right" name="submit">Registration</button>
										<br><br>Already have an account? <a href="index.php">
										Login</a></div>
									<div class="pagination-right"><br></div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div><!--/.wrapper-->

		<div class="footer">
			<div class="container">
				<b class="copyright">&copy; 2022 Online Food Ordering System - Team ENIAC </b> All rights reserved.
			</div>
		</div>
	</body>