-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 05, 2022 at 08:27 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `subcrave_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `categoryName` varchar(255) NOT NULL,
  `categoryDescription` longtext NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `categoryName`, `categoryDescription`, `creationDate`, `updationDate`) VALUES
(11001, 'Buggers', 'Bugger can at times be considered a mild swear word. In the United Kingdom, the term has been used commonly to imply dissatisfaction, refer to someone or something whose behavior is in some way inconvenient, or perhaps as an expression of surprise.', '2022-06-02 07:10:41', '05-06-2022 10:07:19 PM'),
(11002, 'Submarines', 'This Chicken submarine bun contains grilled marinated chicken, sauteed capsicums, onions, cheese, and mayo in a sesame bun. The success of the unique recipes of Dinsmore propelled it to become the first Sri Lankan-origin international fast food restaurant chain.', '2022-06-02 07:12:16', ''),
(11006, 'Juice', 'Good for health', '2022-06-05 16:50:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contactno` bigint(11) NOT NULL,
  `password` varchar(255) NOT NULL,
  `regDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `name`, `email`, `contactno`, `password`, `regDate`, `updationDate`) VALUES
(12, 'Arunika Vidarshani', 'aruniweerasekara96@gmail.com', 715591064, '202cb962ac59075b964b07152d234b70', '2022-06-01 07:40:34', ''),
(14, 'abc avs', 'abc@gmail.com', 711111111, 'e10adc3949ba59abbe56e057f20f883e', '2022-06-03 15:54:39', '03-06-2022 09:25:09 PM'),
(15, 'Nipunika', 'nipu@gmail.com', 773438632, '827ccb0eea8a706c4c34a16891f84e7b', '2022-06-05 14:11:17', '05-06-2022 07:54:14 PM'),
(16, 'Aruni', 'aruni@gmail.com', 776856433, '81dc9bdb52d04dc20036dbd8313ed055', '2022-06-05 14:38:06', ''),
(17, 'Adithya', 'adithya99@gmail.com', 712345678, '81dc9bdb52d04dc20036dbd8313ed055', '2022-06-05 14:39:03', '');

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks`
--

CREATE TABLE `feedbacks` (
  `id` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `quality` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `summary` varchar(255) NOT NULL,
  `review` longtext NOT NULL,
  `reviewDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedbacks`
--

INSERT INTO `feedbacks` (`id`, `productId`, `quality`, `price`, `value`, `name`, `summary`, `review`, `reviewDate`) VALUES
(16, 20, 5, 0, 0, 'Aruni', 'Best', 'This Food very tasty', '2022-03-30 08:14:41'),
(42, 27, 2, 2, 3, 'Weerasekara Mudiyanselage Arunika vidarshani Sumanasekara', 'Best', 'The food are very tasty', '2022-06-02 06:52:51'),
(43, 13001, 2, 2, 0, 'shanali', 'Fernando', 'Good!!! Tasty!!!!', '2022-06-05 14:16:57');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `productId` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `orderDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `paymentMethod` varchar(50) DEFAULT NULL,
  `orderStatus` varchar(55) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `userId`, `productId`, `quantity`, `orderDate`, `paymentMethod`, `orderStatus`) VALUES
(1110001, 12, '13001', 1, '2022-06-03 06:11:02', '', 'Declined'),
(1110002, 14, '13001', 1, '2022-06-03 15:59:31', '', 'Delivered'),
(1110003, 15, '13001', 3, '2022-06-05 14:20:24', '', 'Delivered'),
(1110004, 15, '13002', 2, '2022-06-05 14:20:24', '', 'Delivered'),
(1110005, 16, '13001', 1, '2022-06-05 14:38:28', '', 'Pending'),
(1110006, 17, '13002', 1, '2022-06-05 14:39:21', '', 'Declined');

-- --------------------------------------------------------

--
-- Table structure for table `ordertrackhistory`
--

CREATE TABLE `ordertrackhistory` (
  `id` int(11) NOT NULL,
  `orderId` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `remark` mediumtext NOT NULL,
  `postingDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ordertrackhistory`
--

INSERT INTO `ordertrackhistory` (`id`, `orderId`, `status`, `remark`, `postingDate`) VALUES
(1, 1, 'in Process', 'asdas', '2018-12-11 20:30:12'),
(2, 1, 'Delivered', 'zx', '2018-12-11 20:56:18'),
(3, 2, 'Declined', 'sad', '2018-12-12 09:29:56'),
(4, 2, 'in Process', 'zxc', '2018-12-12 09:30:13'),
(5, 4, 'in Process', 'Your Order is prepering', '2022-03-30 02:05:13'),
(6, 5, 'Delivered', 'success', '2022-03-31 06:04:18'),
(7, 6, 'Delivered', 'done', '2022-03-31 12:12:39'),
(8, 7, 'in Process', 'pending', '2022-03-31 13:08:37'),
(9, 1110001, 'Declined', 'Somthing Error', '2022-06-03 06:11:49'),
(10, 1110002, 'Delivered', 'done', '2022-06-03 16:01:22'),
(11, 1110003, 'in Process', 'wait', '2022-06-05 14:45:25'),
(12, 1110003, 'Delivered', 'delivered', '2022-06-05 14:47:59'),
(13, 1110004, 'in Process', 'wait', '2022-06-05 17:02:38'),
(14, 1110004, 'Delivered', 'Successfully', '2022-06-05 17:05:03'),
(15, 1110006, 'Declined', 'Susseccfully', '2022-06-05 17:06:44');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `subCategory` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `productPrice` int(11) NOT NULL,
  `productDescription` longtext NOT NULL,
  `productImage1` varchar(255) NOT NULL,
  `productImage2` varchar(255) NOT NULL,
  `productImage3` varchar(255) NOT NULL,
  `productAvailability` varchar(255) NOT NULL,
  `postingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category`, `subCategory`, `productName`, `productPrice`, `productDescription`, `productImage1`, `productImage2`, `productImage3`, `productAvailability`, `postingDate`, `updationDate`) VALUES
(13002, 11002, 12002, 'Vegi Submarine', 560, '<span style=\"font-family: sans-serif; font-size: 13.12px; white-space: pre-wrap; background-color: rgb(248, 249, 250);\">Healthy Food With Sub-Crave!!!</span>						', 'vegi sub 2.jpg', 'vegi sub 4.jpg', 'vegi sub1.jpg', 'In Stock', '2022-06-02 07:26:00', ''),
(13003, 11005, 12003, 'Strawberry', 300, '<span style=\"color: rgb(32, 33, 36); font-family: arial, sans-serif; font-size: 16px;\">Strawberry Juice is&nbsp;</span><b style=\"color: rgb(32, 33, 36); font-family: arial, sans-serif; font-size: 16px;\">a refreshing fresh fruit juice</b><span style=\"color: rgb(32, 33, 36); font-family: arial, sans-serif; font-size: 16px;\">&nbsp;that is full of vitamin C and antioxidants and a lot of invigorating flavors. Apart from fresh and ripe strawberries, this recipe also uses lime juice to make it tantalizing!</span>', 'strawberry2.jpg', 'strawberry1.jpg', 'strawberry3.jpg', 'In Stock', '2022-06-05 15:08:41', '');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staffId` int(11) NOT NULL,
  `fullName` varchar(255) CHARACTER SET latin1 NOT NULL,
  `jobType` varchar(100) NOT NULL,
  `userName` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `confirmPassword` varchar(100) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staffId`, `fullName`, `jobType`, `userName`, `password`, `confirmPassword`, `creationDate`, `updationDate`) VALUES
(1001, 'Arunika Vidarshani Sumanasekara', 'Admin', 'Arunika', '81dc9bdb52d04dc20036dbd8313ed055', '827ccb0eea8a706c4c34a16891f84e7b', '2022-06-01 07:20:16', '02-06-2022 12:38:04 PM'),
(1002, 'Shanali', 'Manager', 'sha@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '81dc9bdb52d04dc20036dbd8313ed055', '2022-06-05 13:40:17', NULL),
(1003, 'Adithya', 'Director', 'adi@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '81dc9bdb52d04dc20036dbd8313ed055', '2022-06-05 14:35:54', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE `subcategory` (
  `id` int(11) NOT NULL,
  `categoryid` int(11) NOT NULL,
  `subcategory` varchar(255) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`id`, `categoryid`, `subcategory`, `creationDate`, `updationDate`) VALUES
(12002, 11002, 'Veggie', '2022-06-02 07:20:23', ''),
(12004, 11006, 'berry', '2022-06-05 16:50:27', '');

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `id` int(11) NOT NULL,
  `userEmail` varchar(255) NOT NULL,
  `userip` binary(16) NOT NULL,
  `loginTime` timestamp NOT NULL DEFAULT current_timestamp(),
  `logout` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `userEmail`, `userip`, `loginTime`, `logout`, `status`) VALUES
(62, 'aruniweerasekara96@gmail.com', 0x3a3a3100000000000000000000000000, '2022-06-03 06:11:00', '03-06-2022 09:02:50 PM', 1),
(63, 'abc@gmail.com', 0x3a3a3100000000000000000000000000, '2022-06-03 15:38:06', '03-06-2022 09:24:22 PM', 1),
(64, 'abc@gmail.com', 0x3a3a3100000000000000000000000000, '2022-06-03 15:54:54', '', 1),
(65, 'sha@gmail.com', 0x3a3a3100000000000000000000000000, '2022-06-05 14:05:06', '', 0),
(66, 'nipu@gmail.com', 0x3a3a3100000000000000000000000000, '2022-06-05 14:12:46', '05-06-2022 07:57:23 PM', 1),
(67, 'aruni@gmail.com', 0x3a3a3100000000000000000000000000, '2022-06-05 14:38:18', '05-06-2022 08:08:34 PM', 1),
(68, 'adithya99@gmail.com', 0x3a3a3100000000000000000000000000, '2022-06-05 14:39:20', '', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedbacks`
--
ALTER TABLE `feedbacks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ordertrackhistory`
--
ALTER TABLE `ordertrackhistory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staffId`);

--
-- Indexes for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11007;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `feedbacks`
--
ALTER TABLE `feedbacks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1110007;

--
-- AUTO_INCREMENT for table `ordertrackhistory`
--
ALTER TABLE `ordertrackhistory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13004;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `staffId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1004;

--
-- AUTO_INCREMENT for table `subcategory`
--
ALTER TABLE `subcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12005;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
