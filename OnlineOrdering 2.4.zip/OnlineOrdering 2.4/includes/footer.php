<footer id="footer" class="footer color-bg">
	<div class="links-social inner-top-sm">
        <div class="container">
            <div class="row">
            	<div class="col-xs-12 col-sm-6 col-md-4">
            		<!-- ============================================================= CONTACT INFO ============================================================= -->
                    <div class="contact-info">
                        <div class="footer-logo">
                            <div class="logo">
                                <a href="index.php">
                                    <h3>Sub-Crave Portal</h3>
                                </a>
                            </div><!-- /.logo -->
                        </div><!-- /.footer-logo -->
                        <div class="module-body m-t-20">
                            <div class="social-icons">
                            </div><!-- /.social-icons -->
                        </div><!-- /.module-body -->
                    </div><!-- /.contact-info -->
                    <!-- ============================================================= CONTACT INFO : END ============================================================= -->            	</div><!-- /.col -->

                	<div class="col-xs-12 col-sm-6 col-md-4">
            		 <!-- ============================================================= CONTACT TIMING============================================================= -->
                    <div class="contact-timing">
                        <div class="module-heading">
                            <h4 class="module-title">Opening time</h4>
                        </div><!-- /.module-heading -->

                        <div class="module-body outer-top-xs">
                            <div class="table-responsive">
                                <table class="table">
                                    <tbody>
                                        <tr><td>Monday-Friday:</td><td class="pull-right">07.30 To 
											22.00</td></tr>
                                        <tr><td>Saturday:</td><td class="pull-right">08.00 To 22.00</td></tr>
                                        <tr><td>Sunday:</td><td class="pull-right">10.00 To 22.00</td></tr>
                                    </tbody>
                                </table>
                            </div><!-- /.table-responsive -->
                        </div><!-- /.module-body -->
                    </div><!-- /.contact-timing -->
                    
                    <!-- ============================================================= CONTACT TIMING : END ============================================================= -->            	</div><!-- /.col -->
            	    <div class="col-xs-12 col-sm-6 col-md-4">
            		 <!-- ============================================================= INFORMATION============================================================= -->
                    <div class="contact-information">
                        <div class="module-heading">
                            <h4 class="module-title">Information</h4>
                        </div><!-- /.module-heading -->

                    <div class="module-body outer-top-xs">
                        <ul class="toggle-footer" style="">
                            <li class="media">
                                <div class="pull-left">
                                    <span class="icon fa-stack fa-lg">
                                      <i class="fa fa-circle fa-stack-2x"></i>
                                       <i class="fa fa-map-marker fa-stack-1x fa-inverse"></i>
                                    </span>
                                </div>
                                <div class="media-body">
                                    <p>12/A, Kinross Ave, Bambalapitiya, Colombo 04 </p>
                                </div>
                            </li>

                            <li class="media">
                                <div class="pull-left">
                                    <span class="icon fa-stack fa-lg">
                                        <i class="fa fa-circle fa-stack-2x"></i>
                                        <i class="fa fa-mobile fa-stack-1x fa-inverse"></i>
                                    </span>
                                </div>
                                <div class="media-body">
                                    <p>(+94) 114678233 (Hotline)<br>(+94) 
									773438632 (Mobile)</p>
									<p>E-mail : subcravefoods@gmail.com</p>
                                </div>
                            </li>
                        </ul>
                    </div><!-- /.module-body -->
                </div><!-- /.contact-timing -->
                <!-- ============================================================= INFORMATION : END ============================================================= -->            	</div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </div><!-- /.links-social -->
</footer>
