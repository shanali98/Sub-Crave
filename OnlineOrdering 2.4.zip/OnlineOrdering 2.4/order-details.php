<?php 
	session_start();
	error_reporting(0);
	include('includes/config.php');
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<!-- Meta -->
		<meta charset="utf-8">
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

	    <title>Sub-Crave | Order Details</title>
	    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
	    <link rel="stylesheet" href="assets/css/main.css">
	    <link rel="stylesheet" href="assets/css/red.css">
	    <link rel="stylesheet" href="assets/css/owl.carousel.css">
		<link rel="stylesheet" href="assets/css/owl.transitions.css">
		
		<link href="assets/css/lightbox.css" rel="stylesheet">
		<link rel="stylesheet" href="assets/css/animate.min.css">
		<link rel="stylesheet" href="assets/css/rateit.css">
		<link rel="stylesheet" href="assets/css/bootstrap-select.min.css">

		<link rel="stylesheet" href="assets/css/font-awesome.min.css">
		<link href='http://fonts.googleapis.com/css?family=Roboto:300,400,500,700' rel='stylesheet' type='text/css'>
		<link rel="shortcut icon" href="assets/images/favicon.ico">
		<script language="javascript" type="text/javascript">
			var popUpWin=0;
			function popUpWindow(URLStr, left, top, width, height)
			{
				if(popUpWin)
				{
					if(!popUpWin.closed) popUpWin.close();
				}
					popUpWin = open(URLStr,'popUpWin', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=yes,width='+600+',height='+600+',left='+left+', top='+top+',screenX='+left+',screenY='+top+'');
			}
		</script>
	</head>
    <body class="cnt-home">
				
		<!-- ============================================== HEADER ============================================== -->
		<header class="header-style-1">
			<?php include('includes/top-header.php');?>
			<?php include('includes/main-header.php');?>
			<?php include('includes/menu-bar.php');?>
		</header>
		<!-- ============================================== HEADER : END ============================================== -->
		<div class="breadcrumb">
			<div class="container">
				<div class="breadcrumb-inner">
					<ul class="list-inline list-unstyled">
						<li><a href="index.php">Home</a></li>
						<li class='active'>Shopping Cart</li>
					</ul>
				</div><!-- /.breadcrumb-inner -->
			</div><!-- /.container -->
		</div><!-- /.breadcrumb -->

		<div class="body-content outer-top-xs">
			<div class="container">
				<div class="row inner-bottom-sm">
					<div class="shopping-cart">
						<div class="col-md-12 col-sm-12 shopping-cart-table ">
							<div class="table-responsive">
								<form name="cart" method="post">	
									<table class="table table-bordered">
										<thead>
											<tr>
												<th class="cart-romove item">#</th>
												<th class="cart-description item">Image</th>
												<th class="cart-product-name item">Product Name</th>
										
												<th class="cart-qty item">Quantity</th>
												<th class="cart-sub-total item">Price Per unit</th>
												<th class="cart-total item">Grandtotal</th>
												<th class="cart-total item">Payment Method</th>
												<th class="cart-description item">Order Date</th>
												<th class="cart-total last-item">Action</th>
											</tr>
										</thead><!-- /thead -->
			
										<tbody>
											<?php 
												$orderid=$_POST['orderid'];
												$email=$_POST['email'];

												$sql = "SELECT * FROM products p, 'customer' u, 'orders' o , 'ordertrackhistory' h 
												WHERE p.'id'=o.'productid' AND u.'id'=o.'userId' AND o.'id'=h.'orderId' AND u.'email'='{$email}' and h.'orderId'='{$orderid}' GROUP BY orderId";
											 
												$ret = mysqli_query($conn,$sql);
												$num=mysqli_num_rows($ret);
												
												if($num>0)
												{
										 			while($row=mysqli_fetch_array($ret))
													{
											?>
														<tr>
															<td><?php echo $row['orderId'];?></td> 
															<td class="cart-image">
																 <a class="entry-thumbnail" href="detail.html"> 
																	<img src="admin/productimages/<?php echo $row['productName'].'/'.$row['productImage1']; ?>" alt="" width="84" height="146">
																</a> 
															</td>
															<td class="cart-product-name-info"> 
																<?php echo $row['productName'];?>   
															</td>
															<td class="cart-product-quantity">
																<?php echo $qty=$row['quantity']; ?>   
															</td>
															<td class="cart-product-sub-total"><?php echo $price=$row['productPrice']; ?>  </td>
															<td class="cart-product-grand-total"><?php echo $qty*$price;?></td>
															<td class="cart-product-sub-total"><?php echo $row['paymentMethod']; ?>  </td>
															<td class="cart-product-sub-total"><?php echo $row['orderDate']; ?>  </td>					
															<td>
																<a href="javascript:void(0);" onClick="popUpWindow('track-order.php?oid=<?php echo htmlentities($row['orderId']);?>');" title="Track order">
																Track
															</td>
														</tr>
											<?php 
													} 
												} 
												else 
												{ 
											?>		
													<tr><td colspan="9">Either order id or  Registered email id is invalid</td></tr>
											<?php 
												} 
											
											?>
										</tbody><!-- /tbody -->
									</table><!-- /table -->	
								</form>
							</div>
						</div>
					</div><!-- /.shopping-cart -->
				</div> <!-- /.row -->								
				<!-- ============================================== BRANDS CAROUSEL ============================================== -->
				<?php echo include('includes/brands-slider.php');?>
				<!-- ============================================== BRANDS CAROUSEL : END ============================================== -->	
			</div><!-- /.container -->
		</div><!-- /.body-content -->
		<?php include('includes/footer.php');?>

		<script src="assets/js/jquery-1.11.1.min.js"></script>
		
		<script src="assets/js/bootstrap.min.js"></script>
		
		<script src="assets/js/bootstrap-hover-dropdown.min.js"></script>
		<script src="assets/js/owl.carousel.min.js"></script>
		
		<script src="assets/js/echo.min.js"></script>
		<script src="assets/js/jquery.easing-1.3.min.js"></script>
		<script src="assets/js/bootstrap-slider.min.js"></script>
		<script src="assets/js/jquery.rateit.min.js"></script>
		<script type="text/javascript" src="assets/js/lightbox.min.js"></script>
		<script src="assets/js/bootstrap-select.min.js"></script>
		<script src="assets/js/wow.min.js"></script>
		<script src="assets/js/scripts.js"></script>
	</body>
</html>