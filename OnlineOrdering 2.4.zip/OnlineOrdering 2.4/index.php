<?php
	session_start();
	error_reporting(0);
	include('includes/config.php');
	if(isset($_GET['action']) && $_GET['action']=="add"){
		$id=intval($_GET['id']);
		if(isset($_SESSION['cart'][$id])){
			$_SESSION['cart'][$id]['quantity']++;
		}else{
			$sql_p="SELECT * FROM products WHERE id={$id}";
			$query_p=mysqli_query($conn,$sql_p);
			if(mysqli_num_rows($query_p)!=0){
				$row_p=mysqli_fetch_array($query_p);
				$_SESSION['cart'][$row_p['id']]=array("quantity" => 1, "price" => $row_p['productPrice']);
				header('location:index.php');
			}else{
				$message="Product ID is invalid";
			}
		}
	}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<!-- Meta -->
		<meta charset="utf-8">
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<!-- End Meta -->
		
	    <title>Sub Crave | Home Page</title>

	    <!-- Bootstrap Core CSS -->
	    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
	    
		<!-- Customizable CSS -->
	    <link rel="stylesheet" href="assets/css/main.css">
	    <link rel="stylesheet" href="assets/css/red.css">
	    <link rel="stylesheet" href="assets/css/owl.carousel.css">
		<link rel="stylesheet" href="assets/css/owl.transitions.css">

		<link href="assets/css/lightbox.css" rel="stylesheet">
		<link rel="stylesheet" href="assets/css/animate.min.css">
		<link rel="stylesheet" href="assets/css/rateit.css">
		<link rel="stylesheet" href="assets/css/bootstrap-select.min.css">


		<link rel="stylesheet" href="assets/css/font-awesome.min.css">
		

	</head>
    <body class="cnt-home" style="background-image: url('Admin/background.lpng')">

		<!-- ============================================== HEADER ============================================== -->

		<header class="header-style-1">
			<?php include('includes/top-header.php');?>
			<?php include('includes/main-header.php');?>
			<?php include('includes/menu-bar.php');?>
		</header>

		<!-- ============================================== HEADER : END ============================================== -->

		<div class="body-content outer-top-xs" id="top-banner-and-menu">
			<div class="container">
				<div class="furniture-container homepage-container">
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-3 sidebar">
							<!-- ================================== TOP NAVIGATION ================================== -->
							<?php include('includes/side-menu.php');?>
							<!-- ================================== TOP NAVIGATION : END ================================== -->
							</div><!-- /.sidemenu-holder -->	
								<div class="col-xs-12 col-sm-12 col-md-9 homebanner-holder">
									<!-- ========================================== SECTION – HERO ========================================= -->
									<div id="hero" class="homepage-slider3">
										<div id="owl-main" class="owl-carousel owl-inner-nav owl-ui-sm">
											<div class="full-width-slider">	
												<div class="item" style="background-image: url(assets/images/sliders/xpower.jpg);" width="300" height="300">
												</div><!-- /.item -->
											</div><!-- /.full-width-slider -->
										</div><!-- /.owl-carousel -->
									</div>
									<!-- ========================================= SECTION – HERO : END ========================================= -->	
								</div><!-- /.homebanner-holder -->						
					</div><!-- /.row -->
							<!-- ============================================== SCROLL TABS ============================================== -->
							<div class="tab-content outer-top-xs">
								<div class="tab-pane in active" id="all">			
									<div class="product-slider">
										<div class="owl-carousel home-owl-carousel custom-carousel owl-theme" data-item="4">
											<?php
											$ret=mysqli_query($conn,"select * from products");
											while ($row=mysqli_fetch_array($ret)) 
											{
												# code...
											?>										
											<div class="item item-carousel">
												<div class="products">		
													<div class="product">		
														<div class="product-image">
															<div class="image">
																<a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>">
																<img  src="admin/productimages/<?php echo htmlentities($row['productName']);?>/<?php echo htmlentities($row['productImage1']);?>" data-echo="admin/productimages/<?php echo htmlentities($row['productName']);?>/<?php echo htmlentities($row['productImage1']);?>"  width="250" height="200" alt=""></a>
															</div><!-- /.image -->			
														</div><!-- /.product-image -->
														<div class="product-info text-left">
															<h3 class="name"><a href="product-details.php?pid=<?php echo htmlentities($row['id']);?>"><?php echo htmlentities($row['productName']);?></a></h3>
															<div class="rating rateit-small"></div>
															<div class="description"></div>

															<div class="product-price">	
																<span class="price">
																	Rs.<?php echo htmlentities($row['productPrice']);?>.00	</span>						
															</div><!-- /.product-price -->	
														</div><!-- /.product-info -->
															<div class="action">
																<ul class="list-unstyled">
																	<li class="add-cart-button btn-group">
																		<button class="btn btn-primary icon" data-toggle="dropdown" type="button">
																			<i class="fa fa-shopping-cart"></i>													
																		</button>
																		<a href="category.php?page=product&action=add&id=<?php echo $row['id']; ?>">
																		<button class="btn btn-primary" type="button">Add to cart</button>
																		</a>							
																	</li>						
																</ul>
															</div>
													</div><!-- /.product -->
												</div><!-- /.products -->
											</div><!-- /.item -->
												<?php } ?>
									</div><!-- /.home-owl-carousel -->
								</div><!-- /.product-slider -->
							</div>											
						</div>
					</div>
					<section class="section featured-product inner-xs wow fadeInUp">
						<Br>
						<h3 class="section-title">About Us</h3>
						<p style="font-size:14px; text-align:justify;">
						Sub Crave, a subsidiary of Yum! Brands are the Sri Lankan's largest sub and burgers crave and home of submarines and burgers. 
							Sub-Crave began 30 years ago and today is an iconic global brand that delivers more burgers, submarines, and fresh juice.<br><br>
							To date, Sub-Crave Sri Lanka employs, As an equal opportunity employer, Sub-Crave utilizes 1% of its annual income towards training and welfare. 
							The company strongly believes in creating a results-oriented fun working environment. <br><br>Over the past 24 years, Sub - Crave has grown from strength to strength. 
							At Sub - Crave, we believe in delighting the senses of each and every customer. This is why all dine-in outlets offer a unique family friendly dine-in experience whilst 
							effectively capturing the gastronomic palate of the Sri Lankan consumer with innovative additions to its menu. Currently Sub - Crave serves a wide range of burgers toppings 
							with an exciting selection of special taste as well as appetizers, subers, fresh juice, desserts and beverages.
							</p>
					</section>
				</div>
		</div>
		<?php include('includes/footer.php');?>
				
				<script src="assets/js/jquery-1.11.1.min.js"></script>		
				<script src="assets/js/bootstrap.min.js"></script>		
				<script src="assets/js/bootstrap-hover-dropdown.min.js"></script> 
				<script src="assets/js/owl.carousel.min.js"></script>
				
				 <script src="assets/js/echo.min.js"></script> 
				 <script src="assets/js/jquery.easing-1.3.min.js"></script> 
				 <script src="assets/js/bootstrap-slider.min.js"></script> 
				 <script src="assets/js/jquery.rateit.min.js"></script> 
				 <script type="text/javascript" src="assets/js/lightbox.min.js"></script> 
				 <script src="assets/js/bootstrap-select.min.js"></script> 
				 <script src="assets/js/wow.min.js"></script> 
				<script src="assets/js/scripts.js"></script>

	</body>
</html>